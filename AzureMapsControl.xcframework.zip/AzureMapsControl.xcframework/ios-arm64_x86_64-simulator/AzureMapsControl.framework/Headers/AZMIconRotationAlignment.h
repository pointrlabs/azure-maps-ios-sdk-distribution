//
// Copyright © 2021 Microsoft. All rights reserved.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

typedef NSString * AZMIconRotationAlignment NS_TYPED_ENUM NS_SWIFT_NAME(IconRotationAlignment);

 /// When placement is @C SymbolPlacement.point this is equivalent to @c IconRotationAlignment.viewport .
 /// When placement is @c SymbolPlacement.line this is equivalent to @c IconRotationAlignment.map .
FOUNDATION_EXPORT AZMIconRotationAlignment const AZMIconRotationAlignmentAuto;

 /// When placement is @c SymbolPlacement.point aligns icons east-west.
 /// When placement is @c SymbolPlacement.line aligns the icons' x-axes with the line.
FOUNDATION_EXPORT AZMIconRotationAlignment const AZMIconRotationAlignmentMap;

 /// Icons' x-axes will align with the x-axis of the viewport.
FOUNDATION_EXPORT AZMIconRotationAlignment const AZMIconRotationAlignmentViewport;

NS_ASSUME_NONNULL_END
