//
// Copyright © 2021 Microsoft. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <CoreLocation/CoreLocation.h>

//! Project version number for AzureMapsControl.
FOUNDATION_EXPORT double AzureMapsControlVersionNumber;

//! Project version string for AzureMapsControl.
FOUNDATION_EXPORT const unsigned char AzureMapsControlVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <AzureMapsControl/PublicHeader.h>

#pragma mark - Constants
#import <AzureMapsControl/AZMOptionKey.h>
#import <AzureMapsControl/AZMAccessTokenBlock.h>
#import <AzureMapsControl/AZMAnchorType.h>
#import <AzureMapsControl/AZMAnimationType.h>
#import <AzureMapsControl/AZMAuthenticationType.h>
#import <AzureMapsControl/AZMCameraChangeReason.h>
#import <AzureMapsControl/AZMControlPosition.h>
#import <AzureMapsControl/AZMControlStyle.h>
#import <AzureMapsControl/AZMIconRotationAlignment.h>
#import <AzureMapsControl/AZMIncidentCategory.h>
#import <AzureMapsControl/AZMIncidentMagnitude.h>
#import <AzureMapsControl/AZMLightAnchor.h>
#import <AzureMapsControl/AZMLineCap.h>
#import <AzureMapsControl/AZMLineJoin.h>
#import <AzureMapsControl/AZMMapStyle.h>
#import <AzureMapsControl/AZMSymbolPlacement.h>
#import <AzureMapsControl/AZMTrafficFlow.h>
#import <AzureMapsControl/AZMCirclePitchAlignment.h>
#import <AzureMapsControl/AZMExtrusionFillTranslateAnchor.h>
#import <AzureMapsControl/AZMGlobalConstants.h>

#pragma mark - Additions
#import <AzureMapsControl/NSExpression+AZMAdditions.h>

#pragma mark - Indoor maps
#import <AzureMapsControl/AZMIndoorLayerStyle.h>
#import <AzureMapsControl/AZMIndoorGeography.h>
#import <AzureMapsControl/AZMOptionKey+Indoor.h>
