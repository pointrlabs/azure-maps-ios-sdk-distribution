//
// Copyright © 2021 Microsoft. All rights reserved.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

typedef NSString * AZMIncidentMagnitude NS_TYPED_ENUM NS_SWIFT_NAME(IncidentMagnitude);

/// An incident who's magnitude hasn't yet been classified.
FOUNDATION_EXPORT AZMIncidentMagnitude const AZMIncidentMagnitudeUnknown;

/// A minor traffic issue that is often just for information and has minimal impact to traffic flow.
FOUNDATION_EXPORT AZMIncidentMagnitude const AZMIncidentMagnitudeMinor;

/// A moderate traffic issue that has some impact on traffic flow.
FOUNDATION_EXPORT AZMIncidentMagnitude const AZMIncidentMagnitudeModerate;

/// A major traffic issue that has a significant impact to traffic flow.
FOUNDATION_EXPORT AZMIncidentMagnitude const AZMIncidentMagnitudeMajor;

NS_ASSUME_NONNULL_END
