//
// Copyright © 2021 Microsoft. All rights reserved.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

typedef NSString * AZMAnimationType NS_TYPED_ENUM NS_SWIFT_NAME(AnimationType);

/// It's an immediate change
FOUNDATION_EXPORT AZMAnimationType const AZMAnimationTypeJump;

/// It's a gradual change
FOUNDATION_EXPORT AZMAnimationType const AZMAnimationTypeEase;

/// It's a gradual change
FOUNDATION_EXPORT AZMAnimationType const AZMAnimationTypeFly;

NS_ASSUME_NONNULL_END
