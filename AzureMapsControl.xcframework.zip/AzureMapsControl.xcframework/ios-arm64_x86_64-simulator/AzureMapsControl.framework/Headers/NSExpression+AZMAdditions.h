#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

typedef NSString *AZMExpressionInterpolationMode NS_TYPED_ENUM NS_SWIFT_NAME(ExpressionInterpolationMode);

/**
 An `NSString` identifying the `linear` interpolation type in an `NSExpression`.
 This attribute corresponds to the `linear` value in the interpolate expression operator.
 */
FOUNDATION_EXPORT AZMExpressionInterpolationMode const AZMExpressionInterpolationModeLinear;

/**
 An `NSString` identifying the `expotential` interpolation type in an `NSExpression`.

 This attribute corresponds to the `exponential` value in the interpolate expression operator.
 */
FOUNDATION_EXPORT AZMExpressionInterpolationMode const AZMExpressionInterpolationModeExponential;

/**
 An `NSString` identifying the `cubic-bezier` interpolation type in an `NSExpression`.

 This attribute corresponds to the `cubic-bezier` value in the interpolate expression operator.
 */
FOUNDATION_EXPORT AZMExpressionInterpolationMode const AZMExpressionInterpolationModeCubicBezier;

/**
 Methods for creating expressions that use AzureMap-specific functionality and for
 converting to and from the JSON format.
 */
@interface NSExpression (AZMAdditions)

#pragma mark Creating Variable Expressions

/**
 `NSExpression` variable that corresponds to the zoom expression operator.
 */
@property (class, nonatomic, readonly) NSExpression *azm_zoomLevelVariableExpression NS_SWIFT_NAME(zoomLevelAZMVariable);

/**
 `NSExpression` variable that corresponds to the heatmap-density expression operator.
 */
@property (class, nonatomic, readonly) NSExpression *azm_heatmapDensityVariableExpression NS_SWIFT_NAME(heatmapDensityAZMVariable);

/**
 `NSExpression` variable that corresponds to the line-progress expression operator.
 */
@property (class, nonatomic, readonly) NSExpression *azm_lineProgressVariableExpression NS_SWIFT_NAME(lineProgressAZMVariable);

/**
 `NSExpression` variable that corresponds to the geometry-type expression operator.
 */
@property (class, nonatomic, readonly) NSExpression *azm_geometryTypeVariableExpression NS_SWIFT_NAME(geometryTypeAZMVariable);

/**
 `NSExpression` variable that corresponds to the id expression operator.
 */
@property (class, nonatomic, readonly) NSExpression *azm_featureIdentifierVariableExpression NS_SWIFT_NAME(featureIdentifierAZMVariable);

/**
 `NSExpression` variable that corresponds to the accumulated expression operator.
 */
@property (class, nonatomic, readonly) NSExpression *azm_featureAccumulatedVariableExpression NS_SWIFT_NAME(featureAccumulatedAZMVariable);

/**
 `NSExpression` variable that corresponds to the properties expression operator.
 */
@property (class, nonatomic, readonly) NSExpression *azm_featurePropertiesVariableExpression NS_SWIFT_NAME(featurePropertiesAZMVariable);

#pragma mark Creating Conditional Expressions

/**
 Returns a conditional function expression specifying the string predicate, and
 expressions for each condition.

 @param conditionPredicate The predicate to get evaluated.
 @param trueExpression The expression for conditions equal to true.
 @param falseExpression The expression for conditions equal to false.
 */
+ (instancetype)azm_expressionForConditional:(nonnull NSPredicate *)conditionPredicate trueExpression:(nonnull NSExpression *)trueExpression falseExpresssion:(nonnull NSExpression *)falseExpression NS_SWIFT_NAME(init(forAZMConditional:trueExpression:falseExpression:));

#pragma mark Creating Ramp, Scale, and Curve Expressions

/**
 Returns a step function expression specifying the stepping, from expression
 and stops.

 @param steppingExpression The stepping expression.
 @param minimumExpression The expression which could be a constant or function expression.
 @param stops The stops must be an `NSDictionary` constant `NSExpression`.
 */
+ (instancetype)azm_expressionForSteppingExpression:(nonnull NSExpression*)steppingExpression fromExpression:(nonnull NSExpression *)minimumExpression stops:(nonnull NSExpression*)stops NS_SWIFT_NAME(init(forAZMStepping:from:stops:));

/**
 Returns an interpolated function expression specifying the function operator, curve type,
 parameters and steps.

 @param inputExpression The interpolating expression input.
 @param curveType The curve type could be `AZMExpressionInterpolationModeLinear`,
 `AZMExpressionInterpolationModeExponential` and
 `AZMExpressionInterpolationModeCubicBezier`.
 @param parameters The parameters expression.
 @param stops The stops expression.
 */
+ (instancetype)azm_expressionForInterpolatingExpression:(nonnull NSExpression*)inputExpression withCurveType:(nonnull AZMExpressionInterpolationMode)curveType parameters:(nullable NSExpression *)parameters stops:(nonnull NSExpression*)stops NS_SWIFT_NAME(init(forAZMInterpolating:curveType:parameters:stops:));

/**
 Returns a match function expression specifying the input, matching values,
 and default value.

 @param inputExpression The matching expression.
 @param matchedExpressions The matched values expression dictionary must be condition : value.
 @param defaultExpression The defaultValue expression to be used in case there is no match.
 */
+ (instancetype)azm_expressionForMatchingExpression:(nonnull NSExpression *)inputExpression inDictionary:(nonnull NSDictionary<NSExpression *, NSExpression *> *)matchedExpressions defaultExpression:(nonnull NSExpression *)defaultExpression NS_SWIFT_NAME(init(forAZMMatchingKey:in:default:));

#pragma mark Function Expressions

/**
 Joins the given components into a single string by concatenating each component
 in order.
 */
+ (instancetype)azm_expressionForFunctionJoin:(NSArray<NSExpression *> *)elements NS_SWIFT_NAME(init(forAZMFunctionJoin:));

/**
 Rounds the given number to the nearest integer. If the number is halfway
 between two integers, this method rounds it away from zero.
 */
+ (instancetype)azm_expressionForFunctionRound:(NSNumber *)number NS_SWIFT_NAME(init(forAZMFunctionRound:));

/**
  Computes the principal value of the inverse cosine.
 */
+ (instancetype)azm_expressionForFunctionAcos:(NSNumber *)number NS_SWIFT_NAME(init(forAZMFunctionAcos:));

/**
 Computes the principal value of the cosine.
 */
+ (instancetype)azm_expressionForFunctionCos:(NSNumber *)number NS_SWIFT_NAME(init(forAZMFunctionCos:));

/**
 Computes the principal value of the inverse sine.
 */
+ (instancetype)azm_expressionForFunctionAsin:(NSNumber *)number NS_SWIFT_NAME(init(forAZMFunctionAsin:));

/**
 Computes the principal value of the sine.
 */
+ (instancetype)azm_expressionForFunctionSin:(NSNumber *)number NS_SWIFT_NAME(init(forAZMFunctionSin:));

/**
 Computes the principal value of the inverse tangent.
 */
+ (instancetype)azm_expressionForFunctionAtan:(NSNumber *)number NS_SWIFT_NAME(init(forAZMFunctionAtan:));

/**
 Computes the principal value of the tangent.
 */
+ (instancetype)azm_expressionForFunctionTan:(NSNumber *)number NS_SWIFT_NAME(init(forAZMFunctionTan:));

/**
 Computes the logarithm base two of the value.
 */
+ (instancetype)azm_expressionForFunctionLog2:(NSNumber *)number NS_SWIFT_NAME(init(forAZMFunctionLog2:));

/**
 Returns a straight+line distance from the given shape to the evaluated feature.
 */
+ (instancetype)azm_expressionForFunctionDistanceFrom:(id)object NS_SWIFT_NAME(init(forAZMFunctionDistanceFrom:));

/**
 A placeholder for a method that evaluates a coalesce expression.
 */
+ (instancetype)azm_expressionForFunctionCoalesce:(NSArray<NSExpression *> *)elements NS_SWIFT_NAME(init(forAZMFunctionCoalesce:));

/**
 Returns a Boolean value indicating whether the object has a value for the given
 key.
 */
+ (instancetype)azm_expressionForFunctionDoes:(id)object have:(NSString *)key NS_SWIFT_NAME(init(forAZMFunctionDoes:have:));

#pragma mark Concatenating String Expressions

/**
 Returns a constant expression appending the passed expression.

 @note Both the receiver and the given expression must be an `NSString` constant
 expression type; otherwise, an exception is rised.

 @param expression The expression to append to the receiver.
 */
- (instancetype)azm_expressionByAppendingExpression:(nonnull NSExpression *)expression NS_SWIFT_NAME(azm_appending(_:));

#pragma mark Converting JSON Expressions

/**
 Returns an expression equivalent to the given Foundation object deserialized
 from JSON data.

 @param object A Foundation object deserialized from JSON data, for example
    using `NSJSONSerialization`.
 @return An initialized expression equivalent to `object`, suitable for use as
    the value of a style layer attribute.
 */
+ (instancetype)expressionWithAZMJSONObject:(id)object NS_SWIFT_NAME(init(azmJSONObject:));

/**
 An equivalent Foundation object that can be serialized as JSON.

 You can use `NSJSONSerialization` to serialize the Foundation object as data to
 write to a file.
 */
@property (nonatomic, readonly) id azm_jsonExpressionObject;

#pragma mark Localizing the Expression

/**
 Returns a copy of the receiver localized into the given locale.

 This method assumes the receiver refers to the feature attributes that are
 available in vector tiles supplied by the AzureMap Streets source.
 On iOS, the user can set the system’s preferred language in Settings, General
 Settings, Language & Region. On macOS, the user can set the system’s preferred
 language in the Language & Region pane of System Preferences.

 @param locale The locale into which labels should be localized. To use the
    system’s preferred language, if supported, specify `nil`. To use the local
    language, specify a locale with the identifier `mul`.
 */
- (NSExpression *)azm_expressionLocalizedIntoLocale:(nullable NSLocale *)locale;

@end

NS_ASSUME_NONNULL_END
