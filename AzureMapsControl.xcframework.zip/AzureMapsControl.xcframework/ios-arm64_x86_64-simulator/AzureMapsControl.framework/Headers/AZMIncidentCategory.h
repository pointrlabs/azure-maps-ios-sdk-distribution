//
// Copyright © 2021 Microsoft. All rights reserved.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

typedef NSString * AZMIncidentCategory NS_TYPED_ENUM NS_SWIFT_NAME(IncidentCategory);

/// An incident that either doesn't fit any of the defined categories or hasn't yet been classified.
FOUNDATION_EXPORT AZMIncidentCategory const AZMIncidentCategoryUnknown;

/// Traffic accident.
FOUNDATION_EXPORT AZMIncidentCategory const AZMIncidentCategoryAccident;

/// Fog that reduces visibility, likely reducing traffic flow, and possibly increasing the risk of an accident.
FOUNDATION_EXPORT AZMIncidentCategory const AZMIncidentCategoryFog;

/// Dangerous situation on the road, such as an object on the road.
FOUNDATION_EXPORT AZMIncidentCategory const AZMIncidentCategoryDangerousConditions;

/// Heavy rain that may be reducing visibility, making driving conditions difficult, and possibly increasing the risk of an accident.
FOUNDATION_EXPORT AZMIncidentCategory const AZMIncidentCategoryRain;

/// Icy road conditions that may make driving difficult or dangerous.
FOUNDATION_EXPORT AZMIncidentCategory const AZMIncidentCategoryIce;

/// Traffic jam resulting in slower moving traffic.
FOUNDATION_EXPORT AZMIncidentCategory const AZMIncidentCategoryJam;

/// A road lane is closed.
FOUNDATION_EXPORT AZMIncidentCategory const AZMIncidentCategoryLaneClosed;

/// A road is closed.
FOUNDATION_EXPORT AZMIncidentCategory const AZMIncidentCategoryRoadClosed;

/// Road works/construction in this area.
FOUNDATION_EXPORT AZMIncidentCategory const AZMIncidentCategoryRoadWorks;

/// High winds that may make driving difficult for vehicles with a large side profile or high center of gravity.
FOUNDATION_EXPORT AZMIncidentCategory const AZMIncidentCategoryWind;

/// Flooding occurring on road.
FOUNDATION_EXPORT AZMIncidentCategory const AZMIncidentCategoryFlooding;

/// Traffic being directed to take a detour.
FOUNDATION_EXPORT AZMIncidentCategory const AZMIncidentCategoryDetour;

/// A cluster of traffic incidents of different categories. Zooming in the map will result in the cluster breaking apart into its individual incidents.
FOUNDATION_EXPORT AZMIncidentCategory const AZMIncidentCategoryCluster;

FOUNDATION_EXPORT AZMIncidentCategory AZMIncidentCategoryFromCategoryNumber(NSInteger categoryNumber) NS_SWIFT_NAME(IncidentCategory.init(categoryNumber:));

FOUNDATION_EXPORT NSInteger AZMIncidentCategoryGetCategoryNumber(AZMIncidentCategory category) NS_SWIFT_NAME(getter:IncidentCategory.categoryNumber(self:));

FOUNDATION_EXPORT NSString *AZMIncidentCategoryGetDescription(AZMIncidentCategory category) NS_SWIFT_NAME(getter:IncidentCategory.description(self:));

NS_ASSUME_NONNULL_END
