//
// Copyright © 2021 Microsoft. All rights reserved.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

typedef NSString * AZMSymbolPlacement NS_TYPED_ENUM NS_SWIFT_NAME(SymbolPlacement);

/// The label is placed at the point where the geometry is located
FOUNDATION_EXPORT AZMSymbolPlacement const AZMSymbolPlacementPoint;

/// The label is placed along the line of the geometry. Can only be used on @c LineString and @c Polygon geometries.
FOUNDATION_EXPORT AZMSymbolPlacement const AZMSymbolPlacementLine;

/// The label is placed at the center of the line of the geometry. Can only be
/// used on @c LineString and @c Polygon geometries. Note that a single feature
/// in a vector tile may contain multiple line geometries.
FOUNDATION_EXPORT AZMSymbolPlacement const AZMSymbolPlacementLineCenter;

NS_ASSUME_NONNULL_END
