//
// Copyright © 2021 Microsoft. All rights reserved.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

typedef NSString * AZMControlPosition NS_TYPED_ENUM NS_SWIFT_NAME(ControlPosition);

/// Places the control in the top left of the map.
FOUNDATION_EXPORT AZMControlPosition const AZMControlPositionTopLeft;

/// Places the control in the top right of the map.
FOUNDATION_EXPORT AZMControlPosition const AZMControlPositionTopRight;

/// Places the control in the bottom left of the map.
FOUNDATION_EXPORT AZMControlPosition const AZMControlPositionBottomLeft;

/// Places the control in the bottom right of the map.
FOUNDATION_EXPORT AZMControlPosition const AZMControlPositionBottomRight;

NS_ASSUME_NONNULL_END
