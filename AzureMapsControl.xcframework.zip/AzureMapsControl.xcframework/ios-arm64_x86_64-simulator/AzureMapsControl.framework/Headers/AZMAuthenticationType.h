//
// Copyright © 2021 Microsoft. All rights reserved.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

typedef NSString * AZMAuthenticationType NS_TYPED_ENUM NS_SWIFT_NAME(AuthenticationType);

/// The subscription key authentication mechanism
FOUNDATION_EXPORT AZMAuthenticationType const AZMAuthenticationTypeSubscriptionKey;

/// The Azure Active Directory implicit grant flow authentication mechanism
FOUNDATION_EXPORT AZMAuthenticationType const AZMAuthenticationTypeAAD;

/// Provide your own valid bearer token for authentication.
FOUNDATION_EXPORT AZMAuthenticationType const AZMAuthenticationTypeAccessToken;

NS_ASSUME_NONNULL_END
