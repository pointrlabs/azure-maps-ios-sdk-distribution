//
// Copyright © 2021 Microsoft. All rights reserved.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

typedef NSString * AZMTrafficFlow NS_TYPED_ENUM NS_SWIFT_NAME(TrafficFlow);

/// Display no traffic flow data
FOUNDATION_EXPORT AZMTrafficFlow const AZMTrafficFlowNone;

/// Display absolute speed of the road
FOUNDATION_EXPORT AZMTrafficFlow const AZMTrafficFlowAbsolute;

/// Display speed of the road relative to free-flow
FOUNDATION_EXPORT AZMTrafficFlow const AZMTrafficFlowRelative;

/// Displays relative speed only where they differ from free-flow; false to stop displaying the traffic flow
FOUNDATION_EXPORT AZMTrafficFlow const AZMTrafficFlowRelativeDelay;

NS_ASSUME_NONNULL_END
