//
// Copyright © 2021 Microsoft. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <AzureMapsControl/AZMOptionKey.h>

NS_ASSUME_NONNULL_BEGIN

/// Region of indoor maps.
/// The underlying value type is @c AZMIndoorGeography .
FOUNDATION_EXPORT AZMOptionKey const AZMOptionKeyGeography;
/// Style of indoor layers.
/// The underlying value type is @c AZMIndoorLayerStyle .
FOUNDATION_EXPORT AZMOptionKey const AZMOptionKeyTheme;
/// Tileset id for indoor maps.
/// The underlying value type is @c NSString .
FOUNDATION_EXPORT AZMOptionKey const AZMOptionKeyTilesetID;
/// The underlying value type is @c AZMIndoorControl .
FOUNDATION_EXPORT AZMOptionKey const AZMOptionKeyLevelControl;

NS_ASSUME_NONNULL_END
