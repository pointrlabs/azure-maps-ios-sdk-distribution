//
// Copyright © 2021 Microsoft. All rights reserved.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

typedef NSString * AZMLineJoin NS_TYPED_ENUM NS_SWIFT_NAME(LineJoin);

/// A join with a squared-off end which is drawn beyond the endpoint of the line at a distance of one-half of the lines width.
FOUNDATION_EXPORT AZMLineJoin const AZMLineJoinBevel;

/// A join with a rounded end which is drawn beyond the endpoint of the line at a radius
/// of one-half of the lines width and centered on the endpoint of the line.
FOUNDATION_EXPORT AZMLineJoin const AZMLineJoinRound;

/// A join with a sharp, angled corner which is drawn with the outer sides beyond the endpoint of the path until they meet.
FOUNDATION_EXPORT AZMLineJoin const AZMLineJoinMiter;

NS_ASSUME_NONNULL_END
