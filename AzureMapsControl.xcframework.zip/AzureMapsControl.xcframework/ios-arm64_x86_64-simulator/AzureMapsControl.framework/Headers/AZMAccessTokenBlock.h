//
// Copyright © 2021 Microsoft. All rights reserved.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

/// Block to retrieve the bearer token from your azure maps account.
typedef NSString * _Nonnull (^AZMAccessTokenBlock)(void) NS_SWIFT_NAME(AccessTokenBlock);

NS_ASSUME_NONNULL_END
