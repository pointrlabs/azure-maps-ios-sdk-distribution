//
// Copyright © 2021 Microsoft. All rights reserved.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

/**
 Bitmask values that describe why a camera move occurred.

 It's important to note that it's almost impossible to perform a rotate without zooming (in or out),
 so if you'll often find @c CameraChangeReason.gesturePinch set alongside @c CameraChangeReason.gestureRotate .

 Since there are several reasons why a zoom or rotation has occurred, it is worth considering
 creating a combined constant, for example:

 ```swift
 let anyZoom: CameraChangeReason = [.gesturePinch, .gestureZoomIn, .gestureZoomOut, .gestureOneFingerZoom]

 let anyRotation: CameraChangeReason = [.resetNorth, .gestureRotate]
 ```
 */
typedef NS_OPTIONS(NSUInteger, AZMCameraChangeReason)
{
    /// The reason for the camera change has not been specified.
    AZMCameraChangeReasonNone = 0,

    /// Set when a public API that moves the camera is called. This may be set for some gestures,
    /// for example @c CameraChangeReason.resetNorth .
    AZMCameraChangeReasonProgrammatic = 1 << 0,

    /// The user tapped the compass to reset the map orientation so North is up.
    AZMCameraChangeReasonResetNorth = 1 << 1,

    /// The user panned the map.
    AZMCameraChangeReasonGesturePan = 1 << 2,

    /// The user pinched to zoom in/out.
    AZMCameraChangeReasonGesturePinch = 1 << 3,

    /// The user rotated the map.
    AZMCameraChangeReasonGestureRotate = 1 << 4,

    /// The user zoomed the map in (one finger double tap).
    AZMCameraChangeReasonGestureZoomIn = 1 << 5,

    /// The user zoomed the map out (two finger single tap).
    AZMCameraChangeReasonGestureZoomOut = 1 << 6,

    /// The user long pressed on the map for a quick zoom (single tap, then long press and drag up/down).
    AZMCameraChangeReasonGestureOneFingerZoom = 1 << 7,

    /// The user panned with two fingers to tilt the map (two finger drag).
    AZMCameraChangeReasonGestureTilt = 1 << 8,

    /// Cancelled
    AZMCameraChangeReasonTransitionCancelled = 1 << 16

} NS_SWIFT_NAME(CameraChangeReason); 

NS_ASSUME_NONNULL_END
