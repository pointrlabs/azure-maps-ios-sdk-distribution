//
// Copyright © 2021 Microsoft. All rights reserved.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

typedef NSString * AZMOptionKey NS_TYPED_ENUM NS_SWIFT_NAME(OptionKey);

/// The bearing of the map (rotation) in degrees. When the bearing is 0, 90, 180, or 270 the top of the map container will be north, east, south or west respectively.
/// The underlying value type is @c CLLocationDirection .
FOUNDATION_EXPORT AZMOptionKey const AZMOptionKeyBearing;
/// The position to align the center of the map view with.
/// The underlying value type is @c CLLocationCoordinate2D wrapped in @c NSValue .
FOUNDATION_EXPORT AZMOptionKey const AZMOptionKeyCenter;
/// The pitch (pitch) of the map in degrees between 0 and 60, where 0 is looking straight down on the map.
/// The underlying value type is @c CGFloat .
FOUNDATION_EXPORT AZMOptionKey const AZMOptionKeyPitch;
/// The zoom level of the map view.
/// The underlying value type is @c Double .
FOUNDATION_EXPORT AZMOptionKey const AZMOptionKeyZoom;

/// The configured Authentication type
/// The underlying value type is @c AuthenticationType .
FOUNDATION_EXPORT AZMOptionKey const AZMOptionKeyAuthType;
/// Subscription key from your azure maps account.
/// Must be specified for subscription key auth type.
/// The underlying value type is @c String? .
FOUNDATION_EXPORT AZMOptionKey const AZMOptionKeySubscriptionKey;
/// Bearer token from your azure maps account.
/// Must be specified for access token auth type.
/// The underlying value type is either @c String? or @c AccessTokenBlock? .
FOUNDATION_EXPORT AZMOptionKey const AZMOptionKeyAccessToken;
/// The Azure Maps client ID, This is an unique identifier used to identify the maps account.
/// Preferred to always be specified, but must be specified for AAD and anonymous auth types.
/// The underlying value type is @c String? .
FOUNDATION_EXPORT AZMOptionKey const AZMOptionKeyClientId;
/// The Azure AD registered App ID. This is the app ID of an app registered in your azure AD tenant.
/// Must be specified for AAD auth type.
/// The underlying value type is @c String? .
FOUNDATION_EXPORT AZMOptionKey const AZMOptionKeyAadAppId;
/// The AAD tenant that owns the registered app specified by @c aadAppId .
/// Must be specified for AAD auth type.
/// The underlying value type is @c String? .
FOUNDATION_EXPORT AZMOptionKey const AZMOptionKeyAadTenant;
/// The AAD redirect URI from the registered app specified by @c aadAppId .
/// Must be specified for AAD auth type.
/// The underlying value type is @c String? .
FOUNDATION_EXPORT AZMOptionKey const AZMOptionKeyAadRedirectUri;

/// The domain used by the map.
/// The underlying value type is @c String .
FOUNDATION_EXPORT AZMOptionKey const AZMOptionKeyDomain;

/// The language of the map labels. Available languages can be found in the
/// <a href="https://docs.microsoft.com/en-us/azure/azure-maps/supported-languages">supported languages</a>
/// article.
/// The underlying value type is @c String .
FOUNDATION_EXPORT AZMOptionKey const AZMOptionKeyLanguage;
/// The geopolitical view of the map.
/// The underlying value type is @c String .
FOUNDATION_EXPORT AZMOptionKey const AZMOptionKeyView;
/// The name of the style to use when rendering the map. Available styles can be found in the
/// <a href="https://docs.microsoft.com/en-us/azure/azure-maps/supported-map-styles">supported styles</a>
/// article.
/// The underlying value type is @c MapStyle .
FOUNDATION_EXPORT AZMOptionKey const AZMOptionKeyStyle;
/// Specifies if buildings will be rendered with their models.
/// If false all buildings will be rendered as just their footprints.
/// The underlying value type is @c Bool .
FOUNDATION_EXPORT AZMOptionKey const AZMOptionKeyShowBuildings;

/// Whether extruded geometries are lit relative to the map or viewport.
/// The underlying value type is @c LightAnchor .
FOUNDATION_EXPORT AZMOptionKey const AZMOptionKeyLightAnchor;
/// Color tint for lighting extruded geometries.
/// The underlying value type is @c UIColor .
FOUNDATION_EXPORT AZMOptionKey const AZMOptionKeyLightColor;
/// Intensity of lighting (on a scale from 0 to 1).
/// Higher numbers will present as more extreme contrast.
/// The underlying value type is @c Double .
FOUNDATION_EXPORT AZMOptionKey const AZMOptionKeyLightIntensity;
/// Position of the light source relative to lit (extruded) geometries, in a
/// `LightPosition` struct [radial coordinate, azimuthal angle, polar angle]
/// where radial indicates the distance from the center of the base of an object to
/// its light, azimuthal indicates the position of the light relative to 0° (0°
/// when `OptionKey.lightAnchor` is set to `LightAnchor.viewport` corresponds to the
/// top of the viewport, or 0° when `OptionKey.lightAnchor` is set to `LightAnchor.map`
/// corresponds to due north, and degrees proceed clockwise), and polar indicates
/// the height of the light (from 0°, directly above, to 180°, directly below).
/// The underlying value type is @c LightPosition .
FOUNDATION_EXPORT AZMOptionKey const AZMOptionKeyLightPosition;

/// The type of traffic flow to display.
/// The underlying value type is @c TrafficFlow .
FOUNDATION_EXPORT AZMOptionKey const AZMOptionKeyFlow;
/// Whether to display incidents on the map.
/// The underlying value type is @c Bool .
FOUNDATION_EXPORT AZMOptionKey const AZMOptionKeyIncidents;
/// To filter incidents based on their magnitude.
/// The underlying value type is @c [IncidentMagnitude]? .
FOUNDATION_EXPORT AZMOptionKey const AZMOptionKeyIncidentsMagnitudeFilter;
/// To filter incidents based on their categories.
/// The underlying value type is @c [IncidentCategory]? .
FOUNDATION_EXPORT AZMOptionKey const AZMOptionKeyIncidentsCategoryFilter;

/// A Filter expression.
/// The underlying value type is @c NSExpression? .
FOUNDATION_EXPORT AZMOptionKey const AZMOptionKeyFilter;

/// The maximum zoom level that the map can be zoomed into during the animation. Must be between 0 and 24, and greater than or equal to @c minZoom .
/// The underlying value type is @c Double .
FOUNDATION_EXPORT AZMOptionKey const AZMOptionKeyMaxZoom;
/// The minimum zoom level that the map can be zoomed out to during the animation. Must be between 0 and 24, and less than or equal to @c maxZoom .
/// The underlying value type is @c Double .
FOUNDATION_EXPORT AZMOptionKey const AZMOptionKeyMinZoom;

/// Specifies if the layer is visible or not.
/// The underlying value type is @c Bool .
FOUNDATION_EXPORT AZMOptionKey const AZMOptionKeyVisible;


FOUNDATION_EXPORT AZMOptionKey const AZMOptionKeySource;
/// Required when the source of the layer is a @c VectorTileSource .
/// A vector source can have multiple layers within it, this identifies which one to render in this layer.
/// Prohibited for all other types of sources.
/// The underlying value type is @c String? .
FOUNDATION_EXPORT AZMOptionKey const AZMOptionKeySourceLayer;

/// The amount to blur the circles.
/// A value of 1 blurs the circles such that only the center point if at full opacity.
/// The underlying value type is @c NSExpression .
FOUNDATION_EXPORT AZMOptionKey const AZMOptionKeyBubbleBlur;
/// The color to fill the circle symbol with.
/// The underlying value type is @c NSExpression .
FOUNDATION_EXPORT AZMOptionKey const AZMOptionKeyBubbleColor;
/// The radius of the circle symbols in points.
/// Must be greater than or equal to 0.
/// The underlying value type is @c NSExpression .
FOUNDATION_EXPORT AZMOptionKey const AZMOptionKeyBubbleRadius;
/// Specifies the orientation of circle when map is pitched.
/// The underlying value type is @c NSExpression .
FOUNDATION_EXPORT AZMOptionKey const AZMOptionKeyBubblePitchAlignment;
/// The amount of opacity to apply to the bubble in points.
/// The underlying value type is @c NSExpression .
FOUNDATION_EXPORT AZMOptionKey const AZMOptionKeyBubbleOpacity;
/// The color of the circles' outlines.
/// The underlying value type is @c NSExpression .
FOUNDATION_EXPORT AZMOptionKey const AZMOptionKeyBubbleStrokeColor;
/// A number between 0 and 1 that indicates the opacity at which the circles' outlines will be drawn.
/// The underlying value type is @c NSExpression .
FOUNDATION_EXPORT AZMOptionKey const AZMOptionKeyBubbleStrokeOpacity;
/// The width of the circles' outlines in points.
/// The underlying value type is @c NSExpression .
FOUNDATION_EXPORT AZMOptionKey const AZMOptionKeyBubbleStrokeWidth;

/// Specifies the color gradient used to colorize the points in the heatmap.
/// This is defined using an expression that uses @c NSExpression.heatmapDensityVariable as input.
/// The underlying value type is @c NSExpression .
FOUNDATION_EXPORT AZMOptionKey const AZMOptionKeyHeatmapColor;
/// The radius in points used to render a data point on the heatmap.
/// The radius must be a number greater or equal to 1.
/// The underlying value type is @c NSExpression .
FOUNDATION_EXPORT AZMOptionKey const AZMOptionKeyHeatmapRadius;
/// The opacity at which the heatmap layer will be rendered defined as a number between 0 and 1.
/// The underlying value type is @c NSExpression .
FOUNDATION_EXPORT AZMOptionKey const AZMOptionKeyHeatmapOpacity;
/// Similar to @c heatmapWeight but specifies the global heatmap intensity.
/// The higher this value is, the more ‘weight’ each point will contribute to the appearance.
/// The underlying value type is @c NSExpression .
FOUNDATION_EXPORT AZMOptionKey const AZMOptionKeyHeatmapIntensity;
/// Specifies how much an individual data point contributes to the heatmap.
/// Must be a number greater than 0. A value of 5 would be equivalent to having 5 points of weight 1 in the same spot.
/// This is useful when clustering points to allow heatmap rendering or large datasets.
/// The underlying value type is @c NSExpression .
FOUNDATION_EXPORT AZMOptionKey const AZMOptionKeyHeatmapWeight;

/// The amount of blur to apply to the line in points.
/// The underlying value type is @c NSExpression .
FOUNDATION_EXPORT AZMOptionKey const AZMOptionKeyLineBlur;
/// Specifies how the ends of the lines are rendered.
/// The underlying value type is @c NSExpression .
FOUNDATION_EXPORT AZMOptionKey const AZMOptionKeyLineCap;
/// Specifies how the joints in the lines are rendered.
/// The underlying value type is @c NSExpression .
FOUNDATION_EXPORT AZMOptionKey const AZMOptionKeyLineJoin;
/// The line's offset. A positive value offsets the line to the right, relative to the direction of the line. A negative value offsets to the left.
/// The underlying value type is @c NSExpression .
FOUNDATION_EXPORT AZMOptionKey const AZMOptionKeyLineOffset;

/// Specifies the color of the line.
/// The underlying value type is @c NSExpression .
FOUNDATION_EXPORT AZMOptionKey const AZMOptionKeyStrokeColor;
/// Specifies the lengths of the alternating dashes and gaps that form the dash pattern.
/// Numbers must be equal or greater than 0. The lengths are scaled by the @c strokeWidth .
/// To convert a dash length to points, multiply the length by the current stroke width.
/// The underlying value type is @c NSExpression? .
FOUNDATION_EXPORT AZMOptionKey const AZMOptionKeyStrokeDashArray;
/// A number between 0 and 1 that indicates the opacity at which the line will be drawn.
/// The underlying value type is @c NSExpression .
FOUNDATION_EXPORT AZMOptionKey const AZMOptionKeyStrokeOpacity;
/// The width of the line in points. Must be a value greater or equal to 0.
/// The underlying value type is @c NSExpression .
FOUNDATION_EXPORT AZMOptionKey const AZMOptionKeyStrokeWidth;
/// Defines a gradient with which to color the lines.
/// Requires the @c DataSource.withLineMetrics(_:) option to be set to true.
/// Disabled if @c strokeDashArray is set.
/// The underlying value type is @c NSExpression? .
FOUNDATION_EXPORT AZMOptionKey const AZMOptionKeyStrokeGradient;

/// Specifies if the symbol icon can overlay other symbols on the map.
/// If true the icon will be visible even if it collides with other previously drawn symbols.
/// Tip: Set this to true if animating an symbol to ensure smooth rendering.
/// The underlying value type is @c NSExpression .
FOUNDATION_EXPORT AZMOptionKey const AZMOptionKeyIconAllowOverlap;
/// Specifies which part of the icon is placed closest to the icons anchor position on the map.
/// The underlying value type is @c NSExpression .
FOUNDATION_EXPORT AZMOptionKey const AZMOptionKeyIconAnchor;
/// Specifies if other symbols can overlap this symbol.
/// If true, other symbols can be visible even if they collide with the icon.
/// The underlying value type is @c NSExpression .
FOUNDATION_EXPORT AZMOptionKey const AZMOptionKeyIconIgnorePlacement;
/// The name of the image in the map's image sprite to use for drawing the icon.
/// The underlying value type is @c NSExpression? .
FOUNDATION_EXPORT AZMOptionKey const AZMOptionKeyIconImage;
/// Specifies an @c lineOffset distance of the icon from its anchor in points.
/// Positive values indicate right and down, while negative values indicate left and up.
/// Each component is multiplied by the value of size to obtain the final @c lineOffset in points.
/// When combined with rotation the @c lineOffset will be as if the rotated direction was up.
/// The underlying value type is @c NSExpression .
FOUNDATION_EXPORT AZMOptionKey const AZMOptionKeyIconOffset;
/// A number between 0 and 1 that indicates the opacity at which the icon will be drawn.
/// The underlying value type is @c NSExpression .
FOUNDATION_EXPORT AZMOptionKey const AZMOptionKeyIconOpacity;
/// Specifies if a symbols icon can be hidden but its text displayed if it is overlapped with another symbol.
/// If true, text will display without their corresponding icons
/// when the icon collides with other symbols and the text does not.
/// The underlying value type is @c NSExpression .
FOUNDATION_EXPORT AZMOptionKey const AZMOptionKeyIconOptional;
/// The amount to rotate the icon clockwise in degrees
/// The underlying value type is @c NSExpression .
FOUNDATION_EXPORT AZMOptionKey const AZMOptionKeyIconRotation;
/// In combination with the @c symbolPlacement property of a @c SymbolLayerOption
/// this determines the rotation behavior of icons.
/// The underlying value type is @c NSExpression .
FOUNDATION_EXPORT AZMOptionKey const AZMOptionKeyIconRotationAlignment;
/// Scales the original size of the icon by the provided factor.
/// Must be greater or equal to 0.
/// The underlying value type is @c NSExpression .
FOUNDATION_EXPORT AZMOptionKey const AZMOptionKeyIconSize;

/// Specifies if the text will be visible if it collides with other symbols.
/// If true, the text will be visible even if it collides with other previously drawn symbols.
/// The underlying value type is @c NSExpression .
FOUNDATION_EXPORT AZMOptionKey const AZMOptionKeyTextAllowOverlap;
/// Specifies which part of the icon is placed closest to the icons anchor position on the map.
/// The underlying value type is @c NSExpression .
FOUNDATION_EXPORT AZMOptionKey const AZMOptionKeyTextAnchor;
/// The color of the text.
/// The underlying value type is @c NSExpression .
FOUNDATION_EXPORT AZMOptionKey const AZMOptionKeyTextColor;
/// Specifies the name of a property on the features to use for a text label.
/// The underlying value type is @c NSExpression? .
FOUNDATION_EXPORT AZMOptionKey const AZMOptionKeyTextField;
/// The font stack to use for displaying text.
/// The underlying value type is @c NSExpression .
FOUNDATION_EXPORT AZMOptionKey const AZMOptionKeyTextFont;
/// The halo's fadeout distance towards the outside in points.
/// Must be a number greater or equal to 0.
/// The underlying value type is @c NSExpression .
FOUNDATION_EXPORT AZMOptionKey const AZMOptionKeyTextHaloBlur;
/// The color of the text's halo, which helps it stand out from backgrounds.
/// The underlying value type is @c NSExpression .
FOUNDATION_EXPORT AZMOptionKey const AZMOptionKeyTextHaloColor;
/// The distance of the halo to the font outline in points.
/// Must be a number greater or equal to 0.
/// The maximum text halo width is 1/4 of the font size.
/// The underlying value type is @c NSExpression .
FOUNDATION_EXPORT AZMOptionKey const AZMOptionKeyTextHaloWidth;
/// Specifies if the other symbols are allowed to collide with the text.
/// If true, other symbols can be visible even if they collide with the text.
/// The underlying value type is @c NSExpression .
FOUNDATION_EXPORT AZMOptionKey const AZMOptionKeyTextIgnorePlacement;
/// Specifies an @c lineOffset distance of the icon from its anchor in ems.
/// Positive values indicate right and down, while negative values indicate left and up.
/// The underlying value type is @c NSExpression .
FOUNDATION_EXPORT AZMOptionKey const AZMOptionKeyTextOffset;
/// A number between 0 and 1 that indicates the opacity at which the text will be drawn.
/// The underlying value type is @c NSExpression .
FOUNDATION_EXPORT AZMOptionKey const AZMOptionKeyTextOpacity;
/// Specifies if the text can be hidden if it is overlapped by another symbol.
/// If true, icons will display without their corresponding text
/// when the text collides wit other symbols and the icon does not.
/// The underlying value type is @c NSExpression .
FOUNDATION_EXPORT AZMOptionKey const AZMOptionKeyTextOptional;
/// The size of the font in points.
/// Must be a number greater or equal to 0.
/// The underlying value type is @c NSExpression .
FOUNDATION_EXPORT AZMOptionKey const AZMOptionKeyTextSize;

/// Speciies the label @c symbolPlacement relative to its geometry.
/// Can only be used on @c LineString and @c Polygon geometries.
/// The underlying value type is @c NSExpression .
FOUNDATION_EXPORT AZMOptionKey const AZMOptionKeySymbolPlacement;
/// Distance in points between two symbol anchors along a line. Must be greater or equal to 1.
/// The underlying value type is @c NSExpression .
FOUNDATION_EXPORT AZMOptionKey const AZMOptionKeySymbolSpacing;

/// The position on the map where the popup should be anchored.
/// The underlying value type is @c CLLocationCoordinate2D wrapped in @c NSValue .
FOUNDATION_EXPORT AZMOptionKey const AZMOptionKeyPopupPosition;
/// Popup offset to the right and down, in points, from popup position.
/// Negative value can be used to offset the popup left and up.
/// The underlying value type is @c CGPoint wrapped in @c NSValue .
FOUNDATION_EXPORT AZMOptionKey const AZMOptionKeyPopupOffset;
/// Indicates the popup's location relative to its position on the map.
/// The underlying value is @c AnchorType .
FOUNDATION_EXPORT AZMOptionKey const AZMOptionKeyPopupAnchor;
/// Specifies if the close button should be displayed in the popup or not.
/// The underlying value type is @c Bool .
FOUNDATION_EXPORT AZMOptionKey const AZMOptionKeyPopupClose;
/// The content to display within the popup. Same view cannot be used for multiple popups
/// The underlying value type is @c UIView? .
FOUNDATION_EXPORT AZMOptionKey const AZMOptionKeyPopupContent;

/// The color to fill the polygons with.
/// The underlying value type is @c NSExpression .
FOUNDATION_EXPORT AZMOptionKey const AZMOptionKeyFillColor;
/// A number between 0 and 1 that indicates the opacity at which the fill will be drawn.
/// The underlying value type is @c NSExpression .
FOUNDATION_EXPORT AZMOptionKey const AZMOptionKeyFillOpacity;
/// The pattern to fill the polygons with.
/// The underlying value type is @c NSExpression? .
FOUNDATION_EXPORT AZMOptionKey const AZMOptionKeyFillPattern;

/// The color to fill the polygons with.
/// Ignored if @c fillPattern is set.
/// The underlying value type is @c NSExpression .
FOUNDATION_EXPORT AZMOptionKey const AZMOptionKeyExtrusionFillColor;
/// A number between 0 and 1 that indicates the opacity at which the fill will be drawn.
/// The underlying value type is @c NSExpression .
FOUNDATION_EXPORT AZMOptionKey const AZMOptionKeyExtrusionFillOpacity;
/// The height in meters to extrude this layer.
/// This height is relative to the ground.
/// Must be a number greater or equal to 0.
/// The underlying value type is @c NSExpression .
FOUNDATION_EXPORT AZMOptionKey const AZMOptionKeyExtrusionFillHeight;
/// The height in meters to extrude the base of this layer.
/// This height is relative to the ground.
/// Must be greater or equal to 0 and less than or equal to @c height .
/// The underlying value type is @c NSExpression .
FOUNDATION_EXPORT AZMOptionKey const AZMOptionKeyExtrusionBase;
/// Name of image in sprite to use for drawing image fills.
/// For seamless patterns, image width must be a factor of two (2, 4, 8, ..., 512).
/// The underlying value type is @c NSExpression? .
FOUNDATION_EXPORT AZMOptionKey const AZMOptionKeyExtrusionFillPattern;
/// The polygons' point offset.
/// Values are [x, y] where negatives indicate left and up, respectively.
/// The underlying value type is @c NSExpression .
FOUNDATION_EXPORT AZMOptionKey const AZMOptionKeyExtrusionFillTranslate;
/// Specifies the frame of reference for @c translate .
/// The underlying value type is @c NSExpression .
FOUNDATION_EXPORT AZMOptionKey const AZMOptionKeyExtrusionFillTranslateAnchor;

/// The position the control will be placed on the map. If not specified, the control will be located at the
/// default position it defines.
/// The underlying value type is @c ControlPosition .
FOUNDATION_EXPORT AZMOptionKey const AZMOptionKeyControlPosition;
/// The style of the control.
/// The underlying value type is @c ControlStyle .
FOUNDATION_EXPORT AZMOptionKey const AZMOptionKeyControlStyle;
/// The extent to which the map will zoom with each click of the control.
/// The underlying value type is @c Double .
FOUNDATION_EXPORT AZMOptionKey const AZMOptionKeyZoomDelta;
/// The angle that the map will tilt with each click of the control.
/// The underlying value type is @c Double .
FOUNDATION_EXPORT AZMOptionKey const AZMOptionKeyPitchDegreesDelta;
/// The angle that the map will rotate with each click of the control.
/// The underlying value type is @c Double .
FOUNDATION_EXPORT AZMOptionKey const AZMOptionKeyRotateDegreesDelta;
/// Initial state of geolocate control
FOUNDATION_EXPORT AZMOptionKey const AZMOptionKeyGeolocationEnabled;

/// A number between -1 and 1 that increases or decreases the contrast of the overlay.
/// The underlying value type is @c NSExpression .
FOUNDATION_EXPORT AZMOptionKey const AZMOptionKeyContrast;
/// A number between -1 and 1 that increases or decreases the saturation of the overlay.
/// The underlying value type is @c NSExpression .
FOUNDATION_EXPORT AZMOptionKey const AZMOptionKeySaturation;
/// The duration in milliseconds of a fade transition when a new tile is added. Must be greater or equal to 0.
/// The underlying value type is @c NSExpression .
FOUNDATION_EXPORT AZMOptionKey const AZMOptionKeyFadeDuration;
/// Rotates hues around the color wheel. A number in degrees.
/// The underlying value type is @c NSExpression .
FOUNDATION_EXPORT AZMOptionKey const AZMOptionKeyHueRotation;
/// A number between 0 and 1 that increases or decreases the maximum brightness of the overlay.
/// The underlying value type is @c NSExpression .
FOUNDATION_EXPORT AZMOptionKey const AZMOptionKeyMaxBrightness;
/// A number between 0 and 1 that increases or decreases the minimum brightness of the overlay.
/// The underlying value type is @c NSExpression .
FOUNDATION_EXPORT AZMOptionKey const AZMOptionKeyMinBrightness;
/// A number between 0 and 1 that indicates the opacity at which the overlay will be drawn.
/// The underlying value type is @c NSExpression .
FOUNDATION_EXPORT AZMOptionKey const AZMOptionKeyOpacity;


/// A bounding box that specifies where tiles are available. When specified, no tiles outside of the bounding box will be requested.
/// The underlying value type is @c BoundingBox .
FOUNDATION_EXPORT AZMOptionKey const AZMOptionKeyBounds;
/// The bounds of the map control's camera.
/// The underlying value type is @c BoundingBox? .
FOUNDATION_EXPORT AZMOptionKey const AZMOptionKeyMaxBounds;
/// An integer specifying the minimum zoom level in which tiles are available from the tile source.
/// The underlying value type is @c Int .
FOUNDATION_EXPORT AZMOptionKey const AZMOptionKeyMinSourceZoom;
/// An integer specifying the maximum zoom level in which tiles are available from the tile source.
/// The underlying value type is @c Int .
FOUNDATION_EXPORT AZMOptionKey const AZMOptionKeyMaxSourceZoom;
/// An integer value that specifies the width and height dimensions of the map tiles. For a seamless experience, the tile size must be a multiplier of 2.
/// The underlying value type is @c Int .
FOUNDATION_EXPORT AZMOptionKey const AZMOptionKeyTileSize;
/// Specifies if the tile systems coordinates uses the Tile Map Services specification, which reverses the Y coordinate axis.
/// The underlying value type is @c Bool .
FOUNDATION_EXPORT AZMOptionKey const AZMOptionKeyIsTMS;
/// An array of subdomain values to apply to the tile URL.
/// The underlying value type is @c [String]? .
FOUNDATION_EXPORT AZMOptionKey const AZMOptionKeySubdomains;
/// A http/https URL to a TileJSON resource or a tile URL template that uses the following parameters:
/// {x}: X position of the tile. Usually also needs {y} and {z}.
/// {y}: Y position of the tile. Usually also needs {x} and {z}.
/// {z}: Zoom level of the tile. Usually also needs {x} and {y}.
/// {quadkey}: Tile quadKey id based on the Bing Maps tile system naming convention.
/// {bbox-epsg-3857}: A bounding box string with the format {west},{south},{east},{north} in the EPSG 4325 Spacial Reference System.
/// {subdomain}: A placeholder where the subdomain values if specified will be added.
/// The underlying value type is @c String? .
FOUNDATION_EXPORT AZMOptionKey const AZMOptionKeyTileUrl;
/// An array of one or more tile source URLs. Supported URL parameters:
///  <ul>
///      <li>`{x}` - X position of tile. Tile URL usually also needs {y} and {z}.</li>
///      <li>`{y}` - Y position of tile. Tile URL usually also needs {x} and {z}.</li>
///      <li>`{z}` - Zoom level of tile. Tile URL usually also needs {x} and {y}.</li>
///      <li>`{quadkey}` - Tile quadkey id based on the Bing Maps tile system naming convention.</li>
///      <li>`{bbox-epsg-3857}` - A bounding box string with the format "{west},{south},{east},{north}" with coordinates in the EPSG 3857 Spatial Reference System also commonly known as WGS84 Web Mercator. This is useful when working with WMS imagery services.</li>
///  </ul>
/// The underlying value type is @c [String]? .
FOUNDATION_EXPORT AZMOptionKey const AZMOptionKeyTiles;

/// URL to an image to overlay. Images hosted on other domains must have CORs enabled.
/// The underlying value is @c URL? .
FOUNDATION_EXPORT AZMOptionKey const AZMOptionKeyImageUrl;
/// Image to overlay.
/// The underlying value is @c UIImage? .
FOUNDATION_EXPORT AZMOptionKey const AZMOptionKeyImage;
/// Coordinates for the corners of the image.
/// The underlying value is @c CoordinateQuad .
FOUNDATION_EXPORT AZMOptionKey const AZMOptionKeyImageCoordinates;

/// An offset of the center of the given bounds relative to the map's center, measured in points.
/// The underlying value type is @c UIOffset wrapped in @c NSValue .
FOUNDATION_EXPORT AZMOptionKey const AZMOptionKeyOffset;
/// A point offset to apply to the center of the map.
/// This is useful if you want to programmatically pan the map to another location or if you want to center the map over a shape, then offset the maps view to make room for a popup.
/// The underlying value type is @c UIOffset wrapped in @c NSValue .
FOUNDATION_EXPORT AZMOptionKey const AZMOptionKeyCenterOffset;
/// The amount of padding in points to add to the given bounds.
/// The underlying value type is @c UIEdgeInsets wrapped in @c NSValue .
FOUNDATION_EXPORT AZMOptionKey const AZMOptionKeyPadding;

/// Duration of animation in milliseconds.
/// The underlying value type is @c Double .
FOUNDATION_EXPORT AZMOptionKey const AZMOptionKeyDuration;
/// The type of animation.
/// The underlying value type is @c AnimationType .
FOUNDATION_EXPORT AZMOptionKey const AZMOptionKeyType;

/// A boolean indicating if @c Point features in the source should be clustered or not.
/// If set to true, points will be clustered together into groups by radius.
/// The underlying value type is @c Bool .
FOUNDATION_EXPORT AZMOptionKey const AZMOptionKeyEnableCluster;
/// The radius of each cluster in points.
/// The underlying value type is @c Int .
FOUNDATION_EXPORT AZMOptionKey const AZMOptionKeyClusterRadius;
/// The maximum zoom level in which to cluster points.
/// Defaults to one zoom less than @c maxZoom so that last zoom features are not clustered.
/// The underlying value type is @c Int .
FOUNDATION_EXPORT AZMOptionKey const AZMOptionKeyMaxClusterZoom;
/// Defines custom properties that are calculated using expressions against
/// all the points within each cluster and added to the properties of each cluster point.
/// The underlying value type is @c [ClusterProperty]? .
FOUNDATION_EXPORT AZMOptionKey const AZMOptionKeyClusterProperties;
/// The size of the buffer around each tile.
/// A buffer value of 0 will provide better performance but will be more likely to generate artifacts when rendering.
/// Larger buffers will produce less artifacts but will result in slower performance.
FOUNDATION_EXPORT AZMOptionKey const AZMOptionKeyBuffer;
/// Douglas-Peucker simplification tolerance
/// (higher means simpler geometries and faster performance).
FOUNDATION_EXPORT AZMOptionKey const AZMOptionKeyTolerance;
/// Specifies whether to calculate line distance metrics.
/// This is required for line layers that specify @c ineGradient values.
/// The underlying value type is @c Bool .
FOUNDATION_EXPORT AZMOptionKey const AZMOptionKeyLineMetrics;

/// A boolean indicating whether the map is interactive or static.
/// If false, all user interaction is disabled.
/// If true, only selected user interactions will enabled.
/// The underlying value type is @c Bool .
FOUNDATION_EXPORT AZMOptionKey const AZMOptionKeyInteractive;
/// A boolean indicating whether zoom interactions are enabled.
/// The underlying value type is @c Bool .
FOUNDATION_EXPORT AZMOptionKey const AZMOptionKeyZoomInteraction;
/// A boolean indicating whether rotate interactions are enabled.
/// The underlying value type is @c Bool .
FOUNDATION_EXPORT AZMOptionKey const AZMOptionKeyRotateInteraction;
/// A boolean indicating whether pan interactions are enabled.
/// The underlying value type is @c Bool .
FOUNDATION_EXPORT AZMOptionKey const AZMOptionKeyPanInteraction;
/// A boolean indicating whether pitch interactions are enabled.
/// The underlying value type is @c Bool .
FOUNDATION_EXPORT AZMOptionKey const AZMOptionKeyPitchInteraction;

NS_ASSUME_NONNULL_END
