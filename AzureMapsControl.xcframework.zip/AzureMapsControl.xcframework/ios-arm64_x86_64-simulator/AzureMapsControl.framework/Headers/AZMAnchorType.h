//
// Copyright © 2021 Microsoft. All rights reserved.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

typedef NSString * AZMAnchorType NS_TYPED_ENUM NS_SWIFT_NAME(AnchorType);

/// The center is placed closest to the anchor.
FOUNDATION_EXPORT AZMAnchorType const AZMAnchorTypeCenter;

/// The left side is placed closest to the anchor.
FOUNDATION_EXPORT AZMAnchorType const AZMAnchorTypeLeft;

/// The right side is placed closest to the anchor.
FOUNDATION_EXPORT AZMAnchorType const AZMAnchorTypeRight;

/// The top is placed closest to the anchor.
FOUNDATION_EXPORT AZMAnchorType const AZMAnchorTypeTop;

/// The bottom is placed closest to the anchor.
FOUNDATION_EXPORT AZMAnchorType const AZMAnchorTypeBottom;

/// The top left corner is placed closest to the anchor.
FOUNDATION_EXPORT AZMAnchorType const AZMAnchorTypeTopLeft;

/// The top right corner is placed closest to the anchor.
FOUNDATION_EXPORT AZMAnchorType const AZMAnchorTypeTopRight;

/// The bottom left corner is placed closest to the anchor.
FOUNDATION_EXPORT AZMAnchorType const AZMAnchorTypeBottomLeft;

/// The bottom right corner is placed closest to the anchor.
FOUNDATION_EXPORT AZMAnchorType const AZMAnchorTypeBottomRight;

NS_ASSUME_NONNULL_END
