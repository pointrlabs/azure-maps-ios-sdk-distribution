//
// Copyright © 2021 Microsoft. All rights reserved.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

/// Available styles for a @c Control .
typedef NSString * AZMControlStyle NS_TYPED_ENUM NS_SWIFT_NAME(ControlStyle);

 /// The control will be in the light style.
FOUNDATION_EXPORT AZMControlStyle const AZMControlStyleLight;

 /// The control will be in the dark style.
FOUNDATION_EXPORT AZMControlStyle const AZMControlStyleDark;

NS_ASSUME_NONNULL_END
