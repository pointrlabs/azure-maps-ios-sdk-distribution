//
// Copyright © 2021 Microsoft. All rights reserved.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

typedef NSString * AZMExtrusionFillTranslateAnchor NS_TYPED_ENUM NS_SWIFT_NAME(ExtrusionFillTranslateAnchor);

 /// The fill extrusion is translated relative to the map.
FOUNDATION_EXPORT AZMExtrusionFillTranslateAnchor const AZMExtrusionFillTranslateAnchorMap;

 /// The fill extrusion is translated relative to the viewport.
FOUNDATION_EXPORT AZMExtrusionFillTranslateAnchor const AZMExtrusionFillTranslateAnchorViewport;

NS_ASSUME_NONNULL_END
