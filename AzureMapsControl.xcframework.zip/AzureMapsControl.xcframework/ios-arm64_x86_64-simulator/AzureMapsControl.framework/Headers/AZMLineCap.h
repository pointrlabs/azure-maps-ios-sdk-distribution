//
// Copyright © 2021 Microsoft. All rights reserved.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

typedef NSString * AZMLineCap NS_TYPED_ENUM NS_SWIFT_NAME(LineCap);

/// A cap with a squared-off end which is drawn to the exact endpoint of the line.
FOUNDATION_EXPORT AZMLineCap const AZMLineCapButt;

/// A cap with a rounded end which is drawn beyond the endpoint of the line at a radius of
/// one-half of the line's width and centered on the endpoint of the line.
FOUNDATION_EXPORT AZMLineCap const AZMLineCapRound;

/// A cap with a squared-off end which is drawn beyond the endpoint of the line at a distance of one-half of the line's width.
FOUNDATION_EXPORT AZMLineCap const AZMLineCapSquare;

NS_ASSUME_NONNULL_END
