//
// Copyright © 2021 Microsoft. All rights reserved.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

/// Whether extruded geometries are lit relative to the map or viewport.
typedef NSString * AZMLightAnchor NS_TYPED_ENUM NS_SWIFT_NAME(LightAnchor);

 /// The position of the light source is aligned to the rotation of the map.
FOUNDATION_EXPORT AZMLightAnchor const AZMLightAnchorMap;

 /// The position of the light source is aligned to the rotation of the viewport.
FOUNDATION_EXPORT AZMLightAnchor const AZMLightAnchorViewport;

NS_ASSUME_NONNULL_END
