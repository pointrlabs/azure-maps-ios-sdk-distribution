//
// Copyright © 2021 Microsoft. All rights reserved.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

typedef NSString * AZMIndoorLayerStyle NS_TYPED_ENUM NS_SWIFT_NAME(IndoorLayerStyle);

/// Use current map style theme.
FOUNDATION_EXPORT AZMIndoorLayerStyle const AZMIndoorLayerStyleAuto;

/// Use a dark style if possible.
FOUNDATION_EXPORT AZMIndoorLayerStyle const AZMIndoorLayerStyleDark;

/// Use a light style if possible.
FOUNDATION_EXPORT AZMIndoorLayerStyle const AZMIndoorLayerStyleLight;

NS_ASSUME_NONNULL_END
