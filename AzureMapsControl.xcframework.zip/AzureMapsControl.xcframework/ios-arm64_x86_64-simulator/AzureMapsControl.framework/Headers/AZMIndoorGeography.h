//
// Copyright © 2021 Microsoft. All rights reserved.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

typedef NSString * AZMIndoorGeography NS_TYPED_ENUM NS_SWIFT_NAME(IndoorGeography);

/// Indoor maps for the EU region.
FOUNDATION_EXPORT AZMIndoorGeography const AZMIndoorGeographyEU NS_SWIFT_NAME(eu);

/// Indoor maps for the US region.
FOUNDATION_EXPORT AZMIndoorGeography const AZMIndoorGeographyUS NS_SWIFT_NAME(us);

NS_ASSUME_NONNULL_END
