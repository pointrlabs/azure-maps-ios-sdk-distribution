//
// Copyright © 2021 Microsoft. All rights reserved.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

typedef NSString * AZMMapStyle NS_TYPED_ENUM NS_SWIFT_NAME(MapStyle);

/// Standard map that displays roads, natural and artificial features along with the labels for those features.
FOUNDATION_EXPORT AZMMapStyle const AZMMapStyleRoad;

/// Standard map that displays roads, topographical relief, natural and artificial features along with the labels for those features.
FOUNDATION_EXPORT AZMMapStyle const AZMMapStyleRoadShadedRelief;

/// Combination of satellite and aerial imagery.
FOUNDATION_EXPORT AZMMapStyle const AZMMapStyleSatellite;

/// Hybrid of roads and labels overlaid on top of satellite and aerial imagery.
FOUNDATION_EXPORT AZMMapStyle const AZMMapStyleSatelliteRoadLabels;

/// Light version of the road map style.
FOUNDATION_EXPORT AZMMapStyle const AZMMapStyleGrayscaleLight;

/// Dark version of the road map style.
FOUNDATION_EXPORT AZMMapStyle const AZMMapStyleGrayscaleDark;

/// Dark version of the road map style with colored roads and symbols.
FOUNDATION_EXPORT AZMMapStyle const AZMMapStyleNight;

NS_ASSUME_NONNULL_END
