//
// Copyright © 2021 Microsoft. All rights reserved.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

typedef NSString * AZMCirclePitchAlignment NS_TYPED_ENUM NS_SWIFT_NAME(CirclePitchAlignment);

 /// The circle is aligned to the plane of the map.
FOUNDATION_EXPORT AZMCirclePitchAlignment const AZMCirclePitchAlignmentMap;

 /// The circle is aligned to the plane of the viewport.
FOUNDATION_EXPORT AZMCirclePitchAlignment const AZMCirclePitchAlignmentViewport;

NS_ASSUME_NONNULL_END
